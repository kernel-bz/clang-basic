/**
    file name: Divide/main.c
    author: JungJaeJoon(rgbi3307@nate.com)
    ���: ������ ����
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a, b, c;
    a = 10;
    b = 20;
    c = a / b;  ///10 / 20 == 1 / 2 == 0.5
    printf("result c=%1.1f\n", c); ///float

    return 0;
}
