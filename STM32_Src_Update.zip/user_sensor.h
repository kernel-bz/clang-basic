/**
  ******************************************************************************
  * @file    user_sensor.h
  * @author  JungJaeJoon(rgbi3307@nate.com)
  * @version V01
  * @date    2016-08-21
  * @brief   User Sensor Module Header
  ******************************************************************************
  * @modification
  *
  * COPYRIGHT(c) 2016 www.kernel.bz
  *
  *
  ******************************************************************************
  */

#ifndef __USER_SENSOR_H
#define __USER_SENSOR_H

extern int32_t USensorRightData;
extern int32_t USensorLeftData;

int32_t user_sensor_usnd_read(void);
void user_sensor_test (void);
void user_sensor_set_buzzer(void);

#endif