/**
  ******************************************************************************
  * @file    user_timer.c 
  * @author  JungJaeJoon(rgbi3307@nate.com)
  * @version V01
  * @date    2015-12-19
  * @brief   User Timer Module
  ******************************************************************************
  * @modification
  *
  * COPYRIGHT(c) 2015 www.kernel.bz
  *
  *
  ******************************************************************************
  */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "user_config.h"
#include "user_debug.h"
#include "user_macro.h"
#include "user_gpio.h"
#include "user_rtc.h"
#include "user_timer.h"
#include "usr_adc_dma.h"
#include "user_spi.h"

uint32_t uSecondCount=0;

extern ADC_Data_T ADC_Data;

//TIM_HandleTypeDef    Tim6Handle, Tim7Handle, Tim14Handle;
TIM_HandleTypeDef    Tim6Handle, Tim7Handle;

int8_t user_timer6_init(void)
{
  uint32_t prescaler_value;
  
  //SystemCoreClock: 8MHz
  prescaler_value = (uint32_t) ((SystemCoreClock / 10000) - 1);   //10KHz
  
  Tim6Handle.Instance = TIM6;
   
  Tim6Handle.Init.Period = 10000 - 1;     //1s
  //Tim6Handle.Init.Period = 2000 - 1;     //0.2s
  Tim6Handle.Init.Prescaler = prescaler_value;
  Tim6Handle.Init.ClockDivision = 0;
  Tim6Handle.Init.CounterMode = TIM_COUNTERMODE_UP;
  
  if(HAL_TIM_Base_Init(&Tim6Handle) != HAL_OK)
    return -1;
  
  //Start the TIM Base generation in interrupt mode
  /*
  if(HAL_TIM_Base_Start_IT(&Tim6Handle) != HAL_OK)
    return -2;
  */  
  return 0;  
}

int8_t user_timer7_init(void)
{
  uint32_t prescaler_value;
  
  //SystemCoreClock: 8MHz
  prescaler_value = (uint32_t) ((SystemCoreClock / 1000000) - 1);   //1MHz
  
  Tim7Handle.Instance = TIM7;
   
  //Tim7Handle.Init.Period = 1000000 - 1;     //1s
  //Tim7Handle.Init.Period = 1000 - 1;     //1ms
  Tim7Handle.Init.Period = 10 - 1;     //10us
  Tim7Handle.Init.Prescaler = prescaler_value;
  Tim7Handle.Init.ClockDivision = 0;
  Tim7Handle.Init.CounterMode = TIM_COUNTERMODE_UP;
  if(HAL_TIM_Base_Init(&Tim7Handle) != HAL_OK)
    return -1;
  
  //Start the TIM Base generation in interrupt mode
  /*
  if(HAL_TIM_Base_Start_IT(&Tim7Handle) != HAL_OK)
    return -2;
  */
  
  return 0;  
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    //1s
    if (htim == &Tim6Handle) {
        //user_debug_timer("Timer6 Occured.\r\n");
        //Status LED Toogle
        HAL_GPIO_TogglePin(GPIO_ACTION_STATUS, GPIO_ACTION_STATUS_PIN);
        
        //ADC Value read for Battery, Current, Themistor
        usr_adc_dma_read();
        
        //Read DateTime from RTC
        user_rtc_time_read();   //first
        user_rtc_date_read();   //second

        user_gpio_power_status_led(GPIO_PIN_RESET);
        /**
        Power Module:    50mA
        Sensor Module:   47mA
        Voice Module:    90mA
        Camera Module:  150mA
        Motor Module:    88mA (DC Motor: 70mA avg)
        ---------------------
                        425mA (*)
        RPI3 Booting    400mA
        RPI3 Normal     250mA (*)
        CM3 Booting     900mA
        CM3 Normal      300mA (*)
        HDMI Action     200mA
        KBD/Mouse       100mA
        ---------------------
        Normal          900mA (*)
        Max            2025mA
        */
        if (ADC_Data.curr_value > 2600)     ///600mA
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET); //LED2
        if (ADC_Data.curr_value > 2650)     ///800mA
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET); //LED3
        if (ADC_Data.curr_value > 2700)     ///1000mA
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET); //LED4
        if (ADC_Data.curr_value > 2800)     ///1400mA
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET); //LED5
        
        //User LED
        HAL_GPIO_TogglePin(GPIO_USER_LED1, GPIO_USER_LED1_PIN); //PA12: PE2: User LED1
        HAL_GPIO_TogglePin(GPIO_USER_LED2, GPIO_USER_LED2_PIN); //PA15: PE3: User LED2(Buzzer)
        
        return;
    }

    //10us
    if (htim == &Tim7Handle) {
        //user_debug_timer("Timer7 Occured.\r\n");        
        uSecondCount++;
        return;
    }
}

