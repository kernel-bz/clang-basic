/**
  ******************************************************************************
  * @file    user_timer.h
  * @author  JungJaeJoon(rgbi3307@nate.com)
  * @version V01
  * @date    2015-12-19
  * @brief   User Timer Module Header
  ******************************************************************************
  * @modification
  *
  * COPYRIGHT(c) 2015 www.kernel.bz
  *
  *
  ******************************************************************************
  */

#ifndef __USER_TIMER_H
#define __USER_TIMER_H

#include <stdint.h>

#include "stm32f0xx_hal.h"

extern uint32_t uSecondCount;
extern TIM_HandleTypeDef    Tim6Handle, Tim7Handle;
   
//public
int8_t user_timer6_init(void);
int8_t user_timer7_init(void);

#endif


