/**
  ******************************************************************************
  * @file    user_sensor.c 
  * @author  JungJaeJoon(rgbi3307@nate.com)
  * @version V01
  * @date    2017-12-04
  * @brief   User Sensor Module
  ******************************************************************************
  * @modification
  *
  * COPYRIGHT(c) 2016 www.kernel.bz
  *
  *
  ******************************************************************************
  */

#include "stm32f0xx_adc.h"
#include "stm32f0xx_dma.h"
#include "stm32f0xx_rcc.h"

#include "user_config.h"
#include "user_debug.h"
#include "user_macro.h"
#include "usr_adc_dma.h"
#include "user_gpio.h"
#include "user_sensor.h"
#include "user_timer.h"

int32_t USensorRightData=0;
int32_t USensorLeftData=0;

static void _sensor_us_delay(uint32_t delay)
{
    uSecondCount = 0;
    HAL_TIM_Base_Start_IT(&Tim7Handle);
    delay /= 10;    //10us
    while(uSecondCount < delay) {
        //user_debug_timer("uSecondCount=%d/%d\n", uSecondCount, delay);
    }
    HAL_TIM_Base_Stop_IT(&Tim7Handle);
    //user_debug_timer("uSecondCount=%d/%d\n", uSecondCount, delay);
    uSecondCount = 0;
}

static inline uint32_t _sensor_us_start_count(void)
{
    uSecondCount = 0;
    HAL_TIM_Base_Start_IT(&Tim7Handle);
    return uSecondCount;
}

static inline uint32_t _sensor_us_get_count(void)
{
    HAL_TIM_Base_Stop_IT(&Tim7Handle);
    return uSecondCount * 10;   //10us
}

int32_t user_sensor_usnd_read(void)
{
    uint32_t cnt=0;
    int32_t tick1, tick2;
    GPIO_PinState status;
    float dtime, ds;

    HAL_GPIO_WritePin(GPIO_USER_GPIO1_TRIG, GPIO_USER_GPIO1_PIN, GPIO_PIN_RESET);
    _sensor_us_delay(10);  //10us(2us)
    HAL_GPIO_WritePin(GPIO_USER_GPIO1_TRIG, GPIO_USER_GPIO1_PIN, GPIO_PIN_SET);
    _sensor_us_delay(10);  //10us
    HAL_GPIO_WritePin(GPIO_USER_GPIO1_TRIG, GPIO_USER_GPIO1_PIN, GPIO_PIN_RESET);

    _sensor_us_delay(400);  //400us

    status = HAL_GPIO_ReadPin(GPIO_USER_GPIO2_ECHO, GPIO_USER_GPIO2_PIN);
    while(status != GPIO_PIN_SET) {
        status = HAL_GPIO_ReadPin(GPIO_USER_GPIO2_ECHO, GPIO_USER_GPIO2_PIN);
        cnt++;
        if (cnt > 10) return -1;
        _sensor_us_delay(100);   //100us
    }
    
    tick1 = _sensor_us_start_count();
    while(status == GPIO_PIN_SET) {
        status = HAL_GPIO_ReadPin(GPIO_USER_GPIO2_ECHO, GPIO_USER_GPIO2_PIN);
    }
    tick2 = _sensor_us_get_count();
    
    dtime = tick2 - tick1;
    //ds = (dtime * 340) / 1000 / 2;            ///mm
    ds = (dtime * 340) / 1000 / 2 + 40.5;      ///min:40mm, max:400mm
    
    return (int32_t)ds;
}

void user_sensor_test (void)
{
    int32_t ds;
    
    while(1) {
        ds = user_sensor_usnd_read();
        user_debug_timer ("USensor Distance: %d(mm)\n\n", ds);
        HAL_Delay(100);  //100ms 
    }
}

void user_sensor_set_buzzer(void)
{
    int32_t ds, ds_diff;
    static uint32_t ds_old=0, cnt=0;  
    
    ds = user_sensor_usnd_read();
    ds_diff = ds - ds_old;
    ds_old = ds;
    cnt++;
    if (ds > 300) {
        HAL_GPIO_WritePin(GPIO_USER_LED2, GPIO_USER_LED2_PIN, GPIO_PIN_RESET);  //Buzzer Off
        return ;
    }    
    if (ds_diff * ds_diff < 100) return;
    if (cnt < 60) return;     
    
    cnt = 0;
    //Tim6Handle.Init.Period = 10000 - 1;     //1s
    //Tim6Handle.Init.Period = (ds * ds) / 3;
    Tim6Handle.Init.Period = ds * 50;
    if (ds > 10)
        user_debug_timer ("USensor Distance: %d(cm), Period: %d(ms)\n\n"
                      , ds/10, Tim6Handle.Init.Period/10);
    
    HAL_TIM_Base_Stop_IT(&Tim6Handle);
    HAL_TIM_Base_DeInit(&Tim6Handle);
    
    HAL_TIM_Base_Init(&Tim6Handle);
    HAL_TIM_Base_Start_IT(&Tim6Handle);
}
