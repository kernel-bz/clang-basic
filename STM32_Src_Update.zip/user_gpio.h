/**
  ******************************************************************************
  * @file    user_gpio.h 
  * @author  JungJaeJoon(rgbi3307@nate.com)
  * @version V01
  * @date    2015-08-26
  * @brief   GPIO Module Header
  ******************************************************************************
  * @modification
  *
  * COPYRIGHT(c) 2015 www.kernel.bz
  *
  *
  ******************************************************************************
  */
  
#ifndef __USER_GPIO_H
#define __USER_GPIO_H

#include "stm32f0xx_hal.h"
#include "user_config.h"

#ifdef CONFIG_MACH_POWER

#define GPIO_ACTION_STATUS          GPIOB
#define GPIO_ACTION_STATUS_PIN      GPIO_PIN_3
#define GPIO_ERROR_STATUS           GPIOB
#define GPIO_ERROR_STATUS_PIN       GPIO_PIN_1

//User LED
#define GPIO_USER_LED1              GPIOA
#define GPIO_USER_LED1_PIN          GPIO_PIN_12     //PA12, PE2, User LED1
#define GPIO_USER_LED2              GPIOA
#define GPIO_USER_LED2_PIN          GPIO_PIN_15     //PA15, PE3, User LED2

//User GPIO
#define GPIO_USER_GPIO1_TRIG        GPIOA
#define GPIO_USER_GPIO1_PIN         GPIO_PIN_8     //PA8, PD5, GPIO1 Trig
#define GPIO_USER_GPIO2_ECHO        GPIOA
#define GPIO_USER_GPIO2_PIN         GPIO_PIN_11    //PA11, PD6, GPIO2 Echo

#endif

 void user_gpioA_init(uint16_t gpio_pin, uint32_t mode);
 void user_gpioB_init(uint16_t gpio_pin, uint32_t mode); 
 void user_gpioC_init(uint16_t gpio_pin, uint32_t mode); 
 void user_gpioD_init(uint16_t gpio_pin, uint32_t mode);
 void user_gpioF_init(uint16_t gpio_pin, uint32_t mode); 
 
 void user_gpio_init(void);
 void user_gpio_power_status_led(GPIO_PinState state);
 
int32_t user_gpio_switch_trig(int32_t idx, GPIO_PinState state);
  
#endif
 