/**
  ******************************************************************************
  * @file    user_gpio.c 
  * @author  JungJaeJoon(rgbi3307@nate.com)
  * @version V01
  * @date    2015-08-26
  * @brief   GPIO Module
  ******************************************************************************
  * @modification
  *
  * COPYRIGHT(c) 2015 www.kernel.bz
  *
  *
  ******************************************************************************
  */

#include "main.h"
#include "user_config.h"
#include "user_debug.h"
#include "user_macro.h"
#include "user_isr.h"
#include "user_gpio.h"


//GPIOA Init
void user_gpioA_init(uint16_t gpio_pin, uint32_t mode)
{
  GPIO_InitTypeDef  GPIO_InitStruct;
  
  //Enable the GPIO A clock
  __HAL_RCC_GPIOA_CLK_ENABLE();

  //Configure the GPIOA pin
  GPIO_InitStruct.Pin = gpio_pin;
  GPIO_InitStruct.Mode = mode;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  
  //HAL_GPIO_WritePin(GPIOA, gpio_pin, GPIO_PIN_RESET); 
}

//GPIOB Init
void user_gpioB_init(uint16_t gpio_pin, uint32_t mode)
{
  GPIO_InitTypeDef  GPIO_InitStruct;
  
  //Enable the GPIO B clock
  __HAL_RCC_GPIOB_CLK_ENABLE();

  //Configure the GPIOB pin
  GPIO_InitStruct.Pin = gpio_pin;
  GPIO_InitStruct.Mode = mode;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;         //GPIO_PULLUP(not work)
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
  
  //HAL_GPIO_WritePin(GPIOB, gpio_pin, GPIO_PIN_RESET); 
}

//GPIOC Init
void user_gpioC_init(uint16_t gpio_pin, uint32_t mode)
{
  GPIO_InitTypeDef  GPIO_InitStruct;
  
  //Enable the GPIOC clock
  __HAL_RCC_GPIOC_CLK_ENABLE();

  //Configure the GPIOC pin
  GPIO_InitStruct.Pin = gpio_pin;
  GPIO_InitStruct.Mode = mode;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
  
  //HAL_GPIO_WritePin(GPIOC, gpio_pin, GPIO_PIN_RESET); 
}

//GPIOD Init
void user_gpioD_init(uint16_t gpio_pin, uint32_t mode)
{
  GPIO_InitTypeDef  GPIO_InitStruct;
  
  //Enable the GPIOD clock
  __HAL_RCC_GPIOD_CLK_ENABLE();

  //Configure the GPIOD pin
  GPIO_InitStruct.Pin = gpio_pin;
  GPIO_InitStruct.Mode = mode;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
  
  //HAL_GPIO_WritePin(GPIOD, gpio_pin, GPIO_PIN_RESET); 
}

//GPIOF Init
void user_gpioF_init(uint16_t gpio_pin, uint32_t mode)
{
  GPIO_InitTypeDef  GPIO_InitStruct;
  
  //Enable the GPIOF clock
  __HAL_RCC_GPIOF_CLK_ENABLE();

  //Configure the GPIOF pin
  GPIO_InitStruct.Pin = gpio_pin;
  GPIO_InitStruct.Mode = mode;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);
  
  //HAL_GPIO_WritePin(GPIOF, gpio_pin, GPIO_PIN_RESET); 
}

void user_gpio_init(void)
{
    //Init Switch Trigger
    user_gpioB_init( GPIO_PIN_2, GPIO_MODE_OUTPUT_PP);    //PB2 (GPIO5_SW_RPI)
    user_gpioB_init(GPIO_PIN_12, GPIO_MODE_OUTPUT_PP);    //PB12(VIN_TRIG_GPIO1)
    user_gpioB_init(GPIO_PIN_13, GPIO_MODE_OUTPUT_PP);    //PB13(VIN_TRIG_GPIO2)
    user_gpioB_init(GPIO_PIN_14, GPIO_MODE_OUTPUT_PP);    //PB14(VIN_TRIG_GPIO3)
    user_gpioB_init(GPIO_PIN_15, GPIO_MODE_OUTPUT_PP);    //PB15(VIN_TRIG_GPIO4)
    user_gpioB_init( GPIO_PIN_8, GPIO_MODE_OUTPUT_PP);    //PB8 (VIN_TRIG_GPIO5)

    user_gpio_switch_trig(RESULT_ALL, GPIO_PIN_SET);    //All On
    
    //Init Interrupt
    //user_isr_init(GPIOA, GPIO_PIN_8, EXTI4_15_IRQn, GPIO_MODE_IT_RISING);   //PA8:  IRQ1 (SENSOR)
    //user_isr_init(GPIOA, GPIO_PIN_11, EXTI4_15_IRQn, GPIO_MODE_IT_RISING);  //PA11: IRQ2 (CAMERA)
    user_isr_init(GPIOA, GPIO_PIN_0, EXTI0_1_IRQn, GPIO_MODE_IT_RISING);    //PA0:  IRQ3 (POWER)
    user_isr_init(GPIOC, GPIO_PIN_13, EXTI4_15_IRQn, GPIO_MODE_IT_RISING);  //PC13: IRQ4 (ESP)
    user_isr_init(GPIOA, GPIO_PIN_1, EXTI0_1_IRQn, GPIO_MODE_IT_RISING);    //PA1:  IRQ5 (MAIN, SWITCH,ESP8266)
    //user_isr_init(GPIOA, GPIO_PIN_12, EXTI4_15_IRQn, GPIO_MODE_IT_RISING);  //PA12: IRQ6 (VOICE)
    //user_isr_init(GPIOA, GPIO_PIN_15, EXTI4_15_IRQn, GPIO_MODE_IT_RISING);  //PA15: IRQ7 (MOTOR)
    user_isr_init(GPIOB, GPIO_PIN_9, EXTI4_15_IRQn, GPIO_MODE_IT_RISING);  //PB9: PA3_IRA3
    
    //Init PWM
    user_gpioB_init(GPIO_PIN_4, GPIO_MODE_OUTPUT_PP);     //PB4: PWM1 (LED2)
    user_gpioB_init(GPIO_PIN_5, GPIO_MODE_OUTPUT_PP);     //PB5: PWM2 (LED3)
    user_gpioB_init(GPIO_PIN_0, GPIO_MODE_OUTPUT_PP);     //PB0: PWM3 (LED4)
    user_gpioB_init(GPIO_PIN_1, GPIO_MODE_OUTPUT_PP);     //PB1: PWM4 (LED5)
    user_gpio_power_status_led(GPIO_PIN_RESET);

    user_gpioB_init(GPIO_PIN_3, GPIO_MODE_OUTPUT_PP);       //PB3 (Action Status LED)
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3,  GPIO_PIN_SET);    //ON
    
    //User LED Init
    user_gpioA_init(GPIO_USER_LED1_PIN, GPIO_MODE_OUTPUT_PP);       //PA12: PE2: User LED1
    HAL_GPIO_WritePin(GPIO_USER_LED1, GPIO_USER_LED1_PIN,  GPIO_PIN_RESET);    
    user_gpioA_init(GPIO_USER_LED2_PIN, GPIO_MODE_OUTPUT_PP);       //PA15: PE3: User LED2
    HAL_GPIO_WritePin(GPIO_USER_LED2, GPIO_USER_LED2_PIN,  GPIO_PIN_RESET);
    
    //User GPIO Init
    user_gpioA_init(GPIO_USER_GPIO1_PIN, GPIO_MODE_OUTPUT_PP);       //PA8: PD5: User GPIO1(Trig)
    HAL_GPIO_WritePin(GPIO_USER_GPIO1_TRIG, GPIO_USER_GPIO1_PIN,  GPIO_PIN_RESET);    
    //user_gpioA_init(GPIO_USER_GPIO2_PIN, GPIO_MODE_OUTPUT_PP);       //PA11: PD6: User GPIO2(Echo)
    user_gpioA_init(GPIO_USER_GPIO2_PIN, GPIO_MODE_INPUT);          //PA11: PD6: User GPIO2(Echo)    
    //HAL_GPIO_WritePin(GPIO_USER_GPIO2_ECHO, GPIO_USER_GPIO2_PIN,  GPIO_PIN_RESET);
}

int32_t user_gpio_switch_trig(int32_t idx, GPIO_PinState state)
{
    uint16_t pin[] = {GPIO_PIN_2, GPIO_PIN_12, GPIO_PIN_13, GPIO_PIN_14, GPIO_PIN_15, GPIO_PIN_8};
    //uint16_t pin[] = {GPIO_PIN_2, GPIO_PIN_9, GPIO_PIN_13, GPIO_PIN_14, GPIO_PIN_15};
    
    if (idx < 0) return RESULT_ERR;
    //if (state < 0 || state > 1) return RESULT_ERR;
    
    if (idx < COUNTOF(pin)) {
        HAL_GPIO_WritePin(GPIOB, pin[idx],  state);
        return RESULT_OK;
    } else if (idx & RESULT_ALL) { //All
        uint32_t i;
        for (i=0; i < COUNTOF(pin); i++)
            HAL_GPIO_WritePin(GPIOB, pin[i],  state);
        return RESULT_OK;
    }
    return RESULT_ERR;
}

void user_gpio_power_status_led(GPIO_PinState state)
{
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, state);    //GPIO_PIN_RESET/GPIO_PIN_SET
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, state);  
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, state);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, state);   //PB1 (Error Status LED)
}

/*
void user_gpio_toggle(GPIO_TypeDef* gpiox, uint16_t pin)
{
    HAL_GPIO_TogglePin(GPIO_STATUS, GPIO_STATUS_PIN);
}
*/

